#!/bin/sh

#date	: 2013.12.23
#author	: peterguo
#note	: cold backup mysql data, if use in crontab, please make sure it works
#usage  : crontab */5 * * * * (cd /xxx/xxx/xxx ; sh mysql_cold_backup.sh mysql_cold_backup.ini ) 

if [ $# -eq 0 ];
then
  echo "usage: $0 xxxx.ini" 
  echo "xxxx.ini is like this :"
  echo "xxx.27.198.xx:db_12:t_case,t_machine"
  echo "xxx.27.198.xx:db_34:"
  exit 1
fi

LOCAL_IP=`/sbin/ifconfig eth1 | grep "inet addr:" | awk '{print $2}' | cut -d: -f2`
REMOTE_IP=10.130.83.xx      #[Զ�˵�rsync����ip]
REMOTE_BAK_MOD=autotest_backup
REMOTE_BAK_USR=xxx          #Զ�����õ�rsync����Ŀ¼��

DUMP=/usr/local/mysql/bin/mysqldump
cd $(dirname $0)
WORK_DIR=`pwd`
BAK_DIR=${WORK_DIR}/bak
LOG_DIR=${WORK_DIR}/log
TMP_FILE=/tmp/$$.$0.txt

mkdir -p $BAK_DIR $LOG_DIR

#clear and leave 3 days's file
find bak/ -type f | grep -v $(date +"%Y%m%d" -d "1 days ago") | grep -v $(date +"%Y%m%d" -d "2 days ago") | grep -v $(date +"%Y%m%d") | xargs rm -rf
 
vdate=`date +%Y%m%d`
log_file=${LOG_DIR}/bak_log.${vdate}

echo "[`date +"%Y-%m-%d %H:%M:%S"`] backup " >> ${log_file}

grep $LOCAL_IP $1 | grep -v "^#"  | sed "s/$LOCAL_IP://g" | sed "s/:/ /g" | sed "s/,/ /g" > $TMP_FILE
while read db_name_table 
do
  db_name=`echo $db_name_table | awk '{print $1}'`
  echo "------------------------processing db:[$db_name]----------------------------------"
  ${DUMP} -uroot $db_name_table > $BAK_DIR/$db_name.${vdate}.sql
done < $TMP_FILE

rm $TMP_FILE

vcount=`ls $BAK_DIR/|grep -E "$vdate.sql"|wc -l`
if [ $vcount -gt 0 ];then
  tarfile=mysql_db_${LOCAL_IP}_$vdate.tar.gz
  check_file=CHECK_${LOCAL_IP}
  cd $BAK_DIR
  tar -zcvf $tarfile *.$vdate.sql 

  #du -sh $tarfile > ${check_file}
  ls -l $tarfile | awk '{print $5,$NF}' > ${check_file}
  if [ -e $tarfile ];then
    rm -f *.$vdate.sql
    rsync -av $tarfile  ${REMOTE_BAK_USR}@${REMOTE_IP}::${REMOTE_BAK_MOD}/${vdate}/ 2>>${log_file} 1>> ${log_file}
    echo "rsync -av $tarfile  ${REMOTE_BAK_USR}@${REMOTE_IP}::${REMOTE_BAK_MOD}/${vdate}/" 2>>${log_file} 1>> ${log_file}
    if [ $? -ne 0 ];
    then
        sleep 1m
        rsync -av $tarfile  ${REMOTE_BAK_USR}@${REMOTE_IP}::${REMOTE_BAK_MOD}/${vdate}/ 2>>${log_file} 